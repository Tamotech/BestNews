//
//  AliyunVodPlayerView.h
//  AliyunVodPlayerView
//
//  Created by SMY on 2016/12/29.
//  Copyright © 2016年 SMY. ALl rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AliyunVodPlayerView.
FOUNDATION_EXPORT double AliyunVodPlayerViewSDKVersionNumber;

//! Project version string for AliyunVodPlayerView.
FOUNDATION_EXPORT const unsigned char AliyunVodPlayerViewSDKVersionString[];

// In this header, you should import ALl the public headers of your framework using statements like #import <AliyunVodPlayerViewSDK/PublicHeader.h>


#import <AliyunVodPlayerViewSDK/AliyunVodPlayerView.h>

