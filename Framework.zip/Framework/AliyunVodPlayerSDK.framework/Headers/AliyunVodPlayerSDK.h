//
//  AliyunVodPlayerSDK.h
//  AliyunVodPlayerSDK
//
//  Created by SMY on 2016/12/29.
//  Copyright © 2016年 SMY. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AliyunVodPlayerSDK.
FOUNDATION_EXPORT double AliyunVodPlayerSDKVersionNumber;

//! Project version string for AliyunVodPlayerSDK.
FOUNDATION_EXPORT const unsigned char AliyunVodPlayerSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AliyunVodPlayerSDK/PublicHeader.h>

#import <AliyunVodPlayerSDK/AliyunVodDownLoadManager.h>
#import <AliyunVodPlayerSDK/AliyunVodPlayer.h>
