//
//  RCEvaluateItem.h
//  RongIMLib
//
//  Created by litao on 16/4/29.
//  Copyright © 2016年 RongCloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RCEvaluateItem : NSObject
@property(nonatomic, strong) NSString *describe; // description
@property(nonatomic) int value;
@end
